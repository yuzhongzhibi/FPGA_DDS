/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "E:/Code/ISE/DDS/source/ENCODER.vhd";
extern char *IEEE_P_3620187407;

unsigned char ieee_p_3620187407_sub_4060537613_3965413181(char *, char *, char *, char *, char *);
char *ieee_p_3620187407_sub_436279890_3965413181(char *, char *, char *, char *, int );
char *ieee_p_3620187407_sub_767740470_3965413181(char *, char *, char *, char *, char *, char *);


static void work_a_1881823395_3212880686_p_0(char *t0)
{
    char t29[16];
    char t31[16];
    char t32[16];
    unsigned char t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    unsigned char t6;
    unsigned char t7;
    char *t8;
    char *t9;
    int t10;
    char *t11;
    char *t12;
    int t13;
    char *t14;
    char *t15;
    int t16;
    char *t17;
    char *t18;
    int t19;
    char *t20;
    char *t21;
    int t22;
    char *t23;
    char *t24;
    char *t25;
    char *t26;
    char *t27;
    char *t28;
    unsigned int t30;
    unsigned int t33;

LAB0:    xsi_set_current_line(32, ng0);
    t2 = (t0 + 992U);
    t3 = xsi_signal_has_event(t2);
    if (t3 == 1)
        goto LAB5;

LAB6:    t1 = (unsigned char)0;

LAB7:    if (t1 != 0)
        goto LAB2;

LAB4:
LAB3:    t2 = (t0 + 3952);
    *((int *)t2) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(33, ng0);
    t4 = (t0 + 1832U);
    t8 = *((char **)t4);
    t4 = (t0 + 6588);
    t10 = xsi_mem_cmp(t4, t8, 3U);
    if (t10 == 1)
        goto LAB9;

LAB15:    t11 = (t0 + 6591);
    t13 = xsi_mem_cmp(t11, t8, 3U);
    if (t13 == 1)
        goto LAB10;

LAB16:    t14 = (t0 + 6594);
    t16 = xsi_mem_cmp(t14, t8, 3U);
    if (t16 == 1)
        goto LAB11;

LAB17:    t17 = (t0 + 6597);
    t19 = xsi_mem_cmp(t17, t8, 3U);
    if (t19 == 1)
        goto LAB12;

LAB18:    t20 = (t0 + 6600);
    t22 = xsi_mem_cmp(t20, t8, 3U);
    if (t22 == 1)
        goto LAB13;

LAB19:
LAB14:    xsi_set_current_line(76, ng0);
    t2 = (t0 + 6687);
    t5 = (t0 + 4288);
    t8 = (t5 + 56U);
    t9 = *((char **)t8);
    t11 = (t9 + 56U);
    t12 = *((char **)t11);
    memcpy(t12, t2, 3U);
    xsi_driver_first_trans_fast(t5);

LAB8:    goto LAB3;

LAB5:    t4 = (t0 + 1032U);
    t5 = *((char **)t4);
    t6 = *((unsigned char *)t5);
    t7 = (t6 == (unsigned char)3);
    t1 = t7;
    goto LAB7;

LAB9:    xsi_set_current_line(36, ng0);
    t23 = (t0 + 1192U);
    t24 = *((char **)t23);
    t23 = (t0 + 4032);
    t25 = (t23 + 56U);
    t26 = *((char **)t25);
    t27 = (t26 + 56U);
    t28 = *((char **)t27);
    memcpy(t28, t24, 8U);
    xsi_driver_first_trans_fast(t23);
    xsi_set_current_line(37, ng0);
    t2 = (t0 + 6603);
    t5 = (t0 + 4096);
    t8 = (t5 + 56U);
    t9 = *((char **)t8);
    t11 = (t9 + 56U);
    t12 = *((char **)t11);
    memcpy(t12, t2, 4U);
    xsi_driver_first_trans_fast(t5);
    xsi_set_current_line(38, ng0);
    t2 = (t0 + 6607);
    t5 = (t0 + 4160);
    t8 = (t5 + 56U);
    t9 = *((char **)t8);
    t11 = (t9 + 56U);
    t12 = *((char **)t11);
    memcpy(t12, t2, 4U);
    xsi_driver_first_trans_fast(t5);
    xsi_set_current_line(39, ng0);
    t2 = (t0 + 6611);
    t5 = (t0 + 4224);
    t8 = (t5 + 56U);
    t9 = *((char **)t8);
    t11 = (t9 + 56U);
    t12 = *((char **)t11);
    memcpy(t12, t2, 4U);
    xsi_driver_first_trans_fast(t5);
    xsi_set_current_line(40, ng0);
    t2 = (t0 + 6615);
    t5 = (t0 + 4288);
    t8 = (t5 + 56U);
    t9 = *((char **)t8);
    t11 = (t9 + 56U);
    t12 = *((char **)t11);
    memcpy(t12, t2, 3U);
    xsi_driver_first_trans_fast(t5);
    goto LAB8;

LAB10:    xsi_set_current_line(43, ng0);
    t2 = (t0 + 1992U);
    t4 = *((char **)t2);
    t2 = (t0 + 6484U);
    t5 = (t0 + 6618);
    t9 = (t29 + 0U);
    t11 = (t9 + 0U);
    *((int *)t11) = 0;
    t11 = (t9 + 4U);
    *((int *)t11) = 7;
    t11 = (t9 + 8U);
    *((int *)t11) = 1;
    t10 = (7 - 0);
    t30 = (t10 * 1);
    t30 = (t30 + 1);
    t11 = (t9 + 12U);
    *((unsigned int *)t11) = t30;
    t1 = ieee_p_3620187407_sub_4060537613_3965413181(IEEE_P_3620187407, t4, t2, t5, t29);
    if (t1 != 0)
        goto LAB21;

LAB23:    xsi_set_current_line(48, ng0);
    t2 = (t0 + 6637);
    t5 = (t0 + 4288);
    t8 = (t5 + 56U);
    t9 = *((char **)t8);
    t11 = (t9 + 56U);
    t12 = *((char **)t11);
    memcpy(t12, t2, 3U);
    xsi_driver_first_trans_fast(t5);

LAB22:    goto LAB8;

LAB11:    xsi_set_current_line(52, ng0);
    t2 = (t0 + 1992U);
    t4 = *((char **)t2);
    t2 = (t0 + 6484U);
    t5 = (t0 + 6640);
    t9 = (t29 + 0U);
    t11 = (t9 + 0U);
    *((int *)t11) = 0;
    t11 = (t9 + 4U);
    *((int *)t11) = 7;
    t11 = (t9 + 8U);
    *((int *)t11) = 1;
    t10 = (7 - 0);
    t30 = (t10 * 1);
    t30 = (t30 + 1);
    t11 = (t9 + 12U);
    *((unsigned int *)t11) = t30;
    t1 = ieee_p_3620187407_sub_4060537613_3965413181(IEEE_P_3620187407, t4, t2, t5, t29);
    if (t1 != 0)
        goto LAB28;

LAB30:    xsi_set_current_line(57, ng0);
    t2 = (t0 + 6659);
    t5 = (t0 + 4288);
    t8 = (t5 + 56U);
    t9 = *((char **)t8);
    t11 = (t9 + 56U);
    t12 = *((char **)t11);
    memcpy(t12, t2, 3U);
    xsi_driver_first_trans_fast(t5);

LAB29:    goto LAB8;

LAB12:    xsi_set_current_line(61, ng0);
    t2 = (t0 + 1992U);
    t4 = *((char **)t2);
    t2 = (t0 + 6484U);
    t5 = (t0 + 6662);
    t9 = (t29 + 0U);
    t11 = (t9 + 0U);
    *((int *)t11) = 0;
    t11 = (t9 + 4U);
    *((int *)t11) = 7;
    t11 = (t9 + 8U);
    *((int *)t11) = 1;
    t10 = (7 - 0);
    t30 = (t10 * 1);
    t30 = (t30 + 1);
    t11 = (t9 + 12U);
    *((unsigned int *)t11) = t30;
    t1 = ieee_p_3620187407_sub_4060537613_3965413181(IEEE_P_3620187407, t4, t2, t5, t29);
    if (t1 != 0)
        goto LAB35;

LAB37:    xsi_set_current_line(66, ng0);
    t2 = (t0 + 6681);
    t5 = (t0 + 4288);
    t8 = (t5 + 56U);
    t9 = *((char **)t8);
    t11 = (t9 + 56U);
    t12 = *((char **)t11);
    memcpy(t12, t2, 3U);
    xsi_driver_first_trans_fast(t5);

LAB36:    goto LAB8;

LAB13:    xsi_set_current_line(70, ng0);
    t2 = (t0 + 2152U);
    t4 = *((char **)t2);
    t2 = (t0 + 4352);
    t5 = (t2 + 56U);
    t8 = *((char **)t5);
    t9 = (t8 + 56U);
    t11 = *((char **)t9);
    memcpy(t11, t4, 4U);
    xsi_driver_first_trans_fast_port(t2);
    xsi_set_current_line(71, ng0);
    t2 = (t0 + 2312U);
    t4 = *((char **)t2);
    t2 = (t0 + 4416);
    t5 = (t2 + 56U);
    t8 = *((char **)t5);
    t9 = (t8 + 56U);
    t11 = *((char **)t9);
    memcpy(t11, t4, 4U);
    xsi_driver_first_trans_fast_port(t2);
    xsi_set_current_line(72, ng0);
    t2 = (t0 + 2472U);
    t4 = *((char **)t2);
    t2 = (t0 + 4480);
    t5 = (t2 + 56U);
    t8 = *((char **)t5);
    t9 = (t8 + 56U);
    t11 = *((char **)t9);
    memcpy(t11, t4, 4U);
    xsi_driver_first_trans_fast_port(t2);
    xsi_set_current_line(74, ng0);
    t2 = (t0 + 6684);
    t5 = (t0 + 4288);
    t8 = (t5 + 56U);
    t9 = *((char **)t8);
    t11 = (t9 + 56U);
    t12 = *((char **)t11);
    memcpy(t12, t2, 3U);
    xsi_driver_first_trans_fast(t5);
    goto LAB8;

LAB20:;
LAB21:    xsi_set_current_line(44, ng0);
    t11 = (t0 + 1992U);
    t12 = *((char **)t11);
    t11 = (t0 + 6484U);
    t14 = (t0 + 6626);
    t17 = (t32 + 0U);
    t18 = (t17 + 0U);
    *((int *)t18) = 0;
    t18 = (t17 + 4U);
    *((int *)t18) = 7;
    t18 = (t17 + 8U);
    *((int *)t18) = 1;
    t13 = (7 - 0);
    t30 = (t13 * 1);
    t30 = (t30 + 1);
    t18 = (t17 + 12U);
    *((unsigned int *)t18) = t30;
    t18 = ieee_p_3620187407_sub_767740470_3965413181(IEEE_P_3620187407, t31, t12, t11, t14, t32);
    t20 = (t31 + 12U);
    t30 = *((unsigned int *)t20);
    t33 = (1U * t30);
    t3 = (8U != t33);
    if (t3 == 1)
        goto LAB24;

LAB25:    t21 = (t0 + 4032);
    t23 = (t21 + 56U);
    t24 = *((char **)t23);
    t25 = (t24 + 56U);
    t26 = *((char **)t25);
    memcpy(t26, t18, 8U);
    xsi_driver_first_trans_fast(t21);
    xsi_set_current_line(45, ng0);
    t2 = (t0 + 2472U);
    t4 = *((char **)t2);
    t2 = (t0 + 6532U);
    t5 = ieee_p_3620187407_sub_436279890_3965413181(IEEE_P_3620187407, t29, t4, t2, 1);
    t8 = (t29 + 12U);
    t30 = *((unsigned int *)t8);
    t33 = (1U * t30);
    t1 = (4U != t33);
    if (t1 == 1)
        goto LAB26;

LAB27:    t9 = (t0 + 4224);
    t11 = (t9 + 56U);
    t12 = *((char **)t11);
    t14 = (t12 + 56U);
    t15 = *((char **)t14);
    memcpy(t15, t5, 4U);
    xsi_driver_first_trans_fast(t9);
    xsi_set_current_line(46, ng0);
    t2 = (t0 + 6634);
    t5 = (t0 + 4288);
    t8 = (t5 + 56U);
    t9 = *((char **)t8);
    t11 = (t9 + 56U);
    t12 = *((char **)t11);
    memcpy(t12, t2, 3U);
    xsi_driver_first_trans_fast(t5);
    goto LAB22;

LAB24:    xsi_size_not_matching(8U, t33, 0);
    goto LAB25;

LAB26:    xsi_size_not_matching(4U, t33, 0);
    goto LAB27;

LAB28:    xsi_set_current_line(53, ng0);
    t11 = (t0 + 1992U);
    t12 = *((char **)t11);
    t11 = (t0 + 6484U);
    t14 = (t0 + 6648);
    t17 = (t32 + 0U);
    t18 = (t17 + 0U);
    *((int *)t18) = 0;
    t18 = (t17 + 4U);
    *((int *)t18) = 7;
    t18 = (t17 + 8U);
    *((int *)t18) = 1;
    t13 = (7 - 0);
    t30 = (t13 * 1);
    t30 = (t30 + 1);
    t18 = (t17 + 12U);
    *((unsigned int *)t18) = t30;
    t18 = ieee_p_3620187407_sub_767740470_3965413181(IEEE_P_3620187407, t31, t12, t11, t14, t32);
    t20 = (t31 + 12U);
    t30 = *((unsigned int *)t20);
    t33 = (1U * t30);
    t3 = (8U != t33);
    if (t3 == 1)
        goto LAB31;

LAB32:    t21 = (t0 + 4032);
    t23 = (t21 + 56U);
    t24 = *((char **)t23);
    t25 = (t24 + 56U);
    t26 = *((char **)t25);
    memcpy(t26, t18, 8U);
    xsi_driver_first_trans_fast(t21);
    xsi_set_current_line(54, ng0);
    t2 = (t0 + 2312U);
    t4 = *((char **)t2);
    t2 = (t0 + 6516U);
    t5 = ieee_p_3620187407_sub_436279890_3965413181(IEEE_P_3620187407, t29, t4, t2, 1);
    t8 = (t29 + 12U);
    t30 = *((unsigned int *)t8);
    t33 = (1U * t30);
    t1 = (4U != t33);
    if (t1 == 1)
        goto LAB33;

LAB34:    t9 = (t0 + 4160);
    t11 = (t9 + 56U);
    t12 = *((char **)t11);
    t14 = (t12 + 56U);
    t15 = *((char **)t14);
    memcpy(t15, t5, 4U);
    xsi_driver_first_trans_fast(t9);
    xsi_set_current_line(55, ng0);
    t2 = (t0 + 6656);
    t5 = (t0 + 4288);
    t8 = (t5 + 56U);
    t9 = *((char **)t8);
    t11 = (t9 + 56U);
    t12 = *((char **)t11);
    memcpy(t12, t2, 3U);
    xsi_driver_first_trans_fast(t5);
    goto LAB29;

LAB31:    xsi_size_not_matching(8U, t33, 0);
    goto LAB32;

LAB33:    xsi_size_not_matching(4U, t33, 0);
    goto LAB34;

LAB35:    xsi_set_current_line(62, ng0);
    t11 = (t0 + 1992U);
    t12 = *((char **)t11);
    t11 = (t0 + 6484U);
    t14 = (t0 + 6670);
    t17 = (t32 + 0U);
    t18 = (t17 + 0U);
    *((int *)t18) = 0;
    t18 = (t17 + 4U);
    *((int *)t18) = 7;
    t18 = (t17 + 8U);
    *((int *)t18) = 1;
    t13 = (7 - 0);
    t30 = (t13 * 1);
    t30 = (t30 + 1);
    t18 = (t17 + 12U);
    *((unsigned int *)t18) = t30;
    t18 = ieee_p_3620187407_sub_767740470_3965413181(IEEE_P_3620187407, t31, t12, t11, t14, t32);
    t20 = (t31 + 12U);
    t30 = *((unsigned int *)t20);
    t33 = (1U * t30);
    t3 = (8U != t33);
    if (t3 == 1)
        goto LAB38;

LAB39:    t21 = (t0 + 4032);
    t23 = (t21 + 56U);
    t24 = *((char **)t23);
    t25 = (t24 + 56U);
    t26 = *((char **)t25);
    memcpy(t26, t18, 8U);
    xsi_driver_first_trans_fast(t21);
    xsi_set_current_line(63, ng0);
    t2 = (t0 + 2152U);
    t4 = *((char **)t2);
    t2 = (t0 + 6500U);
    t5 = ieee_p_3620187407_sub_436279890_3965413181(IEEE_P_3620187407, t29, t4, t2, 1);
    t8 = (t29 + 12U);
    t30 = *((unsigned int *)t8);
    t33 = (1U * t30);
    t1 = (4U != t33);
    if (t1 == 1)
        goto LAB40;

LAB41:    t9 = (t0 + 4096);
    t11 = (t9 + 56U);
    t12 = *((char **)t11);
    t14 = (t12 + 56U);
    t15 = *((char **)t14);
    memcpy(t15, t5, 4U);
    xsi_driver_first_trans_fast(t9);
    xsi_set_current_line(64, ng0);
    t2 = (t0 + 6678);
    t5 = (t0 + 4288);
    t8 = (t5 + 56U);
    t9 = *((char **)t8);
    t11 = (t9 + 56U);
    t12 = *((char **)t11);
    memcpy(t12, t2, 3U);
    xsi_driver_first_trans_fast(t5);
    goto LAB36;

LAB38:    xsi_size_not_matching(8U, t33, 0);
    goto LAB39;

LAB40:    xsi_size_not_matching(4U, t33, 0);
    goto LAB41;

}


extern void work_a_1881823395_3212880686_init()
{
	static char *pe[] = {(void *)work_a_1881823395_3212880686_p_0};
	xsi_register_didat("work_a_1881823395_3212880686", "isim/top_sim_isim_beh.exe.sim/work/a_1881823395_3212880686.didat");
	xsi_register_executes(pe);
}
