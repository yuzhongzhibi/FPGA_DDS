/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "E:/Code/ISE/DDS/source/DYNAMIC_LED.vhd";



static void work_a_1503986837_3212880686_p_0(char *t0)
{
    unsigned char t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    unsigned char t6;
    unsigned char t7;
    char *t8;
    int t9;
    unsigned char t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    int t15;

LAB0:    xsi_set_current_line(29, ng0);
    t2 = (t0 + 992U);
    t3 = xsi_signal_has_event(t2);
    if (t3 == 1)
        goto LAB5;

LAB6:    t1 = (unsigned char)0;

LAB7:    if (t1 != 0)
        goto LAB2;

LAB4:
LAB3:    t2 = (t0 + 4128);
    *((int *)t2) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(30, ng0);
    t4 = (t0 + 1992U);
    t8 = *((char **)t4);
    t9 = *((int *)t8);
    t10 = (t9 == 2);
    if (t10 != 0)
        goto LAB8;

LAB10:    xsi_set_current_line(33, ng0);
    t2 = (t0 + 1992U);
    t4 = *((char **)t2);
    t9 = *((int *)t4);
    t15 = (t9 + 1);
    t2 = (t0 + 4240);
    t5 = (t2 + 56U);
    t8 = *((char **)t5);
    t11 = (t8 + 56U);
    t12 = *((char **)t11);
    *((int *)t12) = t15;
    xsi_driver_first_trans_fast(t2);

LAB9:    goto LAB3;

LAB5:    t4 = (t0 + 1032U);
    t5 = *((char **)t4);
    t6 = *((unsigned char *)t5);
    t7 = (t6 == (unsigned char)3);
    t1 = t7;
    goto LAB7;

LAB8:    xsi_set_current_line(31, ng0);
    t4 = (t0 + 4240);
    t11 = (t4 + 56U);
    t12 = *((char **)t11);
    t13 = (t12 + 56U);
    t14 = *((char **)t13);
    *((int *)t14) = 0;
    xsi_driver_first_trans_fast(t4);
    goto LAB9;

}

static void work_a_1503986837_3212880686_p_1(char *t0)
{
    unsigned char t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    unsigned char t6;
    unsigned char t7;
    char *t8;
    int t9;
    char *t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;

LAB0:    xsi_set_current_line(40, ng0);
    t2 = (t0 + 992U);
    t3 = xsi_signal_has_event(t2);
    if (t3 == 1)
        goto LAB5;

LAB6:    t1 = (unsigned char)0;

LAB7:    if (t1 != 0)
        goto LAB2;

LAB4:
LAB3:    t2 = (t0 + 4144);
    *((int *)t2) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(41, ng0);
    t4 = (t0 + 1992U);
    t8 = *((char **)t4);
    t9 = *((int *)t8);
    if (t9 == 0)
        goto LAB9;

LAB13:    if (t9 == 1)
        goto LAB10;

LAB14:    if (t9 == 2)
        goto LAB11;

LAB15:
LAB12:    xsi_set_current_line(55, ng0);
    t2 = (t0 + 6700);
    t5 = (t0 + 4304);
    t8 = (t5 + 56U);
    t10 = *((char **)t8);
    t11 = (t10 + 56U);
    t12 = *((char **)t11);
    memcpy(t12, t2, 8U);
    xsi_driver_first_trans_fast_port(t5);

LAB8:    goto LAB3;

LAB5:    t4 = (t0 + 1032U);
    t5 = *((char **)t4);
    t6 = *((unsigned char *)t5);
    t7 = (t6 == (unsigned char)3);
    t1 = t7;
    goto LAB7;

LAB9:    xsi_set_current_line(44, ng0);
    t4 = (t0 + 6676);
    t11 = (t0 + 4304);
    t12 = (t11 + 56U);
    t13 = *((char **)t12);
    t14 = (t13 + 56U);
    t15 = *((char **)t14);
    memcpy(t15, t4, 8U);
    xsi_driver_first_trans_fast_port(t11);
    xsi_set_current_line(45, ng0);
    t2 = (t0 + 1512U);
    t4 = *((char **)t2);
    t2 = (t0 + 4368);
    t5 = (t2 + 56U);
    t8 = *((char **)t5);
    t10 = (t8 + 56U);
    t11 = *((char **)t10);
    memcpy(t11, t4, 4U);
    xsi_driver_first_trans_fast(t2);
    goto LAB8;

LAB10:    xsi_set_current_line(48, ng0);
    t2 = (t0 + 6684);
    t5 = (t0 + 4304);
    t8 = (t5 + 56U);
    t10 = *((char **)t8);
    t11 = (t10 + 56U);
    t12 = *((char **)t11);
    memcpy(t12, t2, 8U);
    xsi_driver_first_trans_fast_port(t5);
    xsi_set_current_line(49, ng0);
    t2 = (t0 + 1352U);
    t4 = *((char **)t2);
    t2 = (t0 + 4368);
    t5 = (t2 + 56U);
    t8 = *((char **)t5);
    t10 = (t8 + 56U);
    t11 = *((char **)t10);
    memcpy(t11, t4, 4U);
    xsi_driver_first_trans_fast(t2);
    goto LAB8;

LAB11:    xsi_set_current_line(52, ng0);
    t2 = (t0 + 6692);
    t5 = (t0 + 4304);
    t8 = (t5 + 56U);
    t10 = *((char **)t8);
    t11 = (t10 + 56U);
    t12 = *((char **)t11);
    memcpy(t12, t2, 8U);
    xsi_driver_first_trans_fast_port(t5);
    xsi_set_current_line(53, ng0);
    t2 = (t0 + 1192U);
    t4 = *((char **)t2);
    t2 = (t0 + 4368);
    t5 = (t2 + 56U);
    t8 = *((char **)t5);
    t10 = (t8 + 56U);
    t11 = *((char **)t10);
    memcpy(t11, t4, 4U);
    xsi_driver_first_trans_fast(t2);
    goto LAB8;

LAB16:;
}

static void work_a_1503986837_3212880686_p_2(char *t0)
{
    unsigned char t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    unsigned char t6;
    unsigned char t7;
    char *t8;
    int t9;
    unsigned char t10;
    char *t11;
    char *t12;
    int t13;
    char *t14;
    char *t15;
    int t16;
    char *t17;
    char *t18;
    int t19;
    char *t20;
    char *t21;
    int t22;
    char *t23;
    char *t24;
    int t25;
    char *t26;
    char *t27;
    int t28;
    char *t29;
    char *t30;
    int t31;
    char *t32;
    char *t33;
    int t34;
    char *t35;
    char *t36;
    int t37;
    char *t38;
    char *t39;
    int t40;
    char *t41;
    char *t42;
    char *t43;
    char *t44;
    char *t45;
    char *t46;
    char *t47;

LAB0:    xsi_set_current_line(62, ng0);
    t2 = (t0 + 992U);
    t3 = xsi_signal_has_event(t2);
    if (t3 == 1)
        goto LAB5;

LAB6:    t1 = (unsigned char)0;

LAB7:    if (t1 != 0)
        goto LAB2;

LAB4:
LAB3:    t2 = (t0 + 4160);
    *((int *)t2) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(64, ng0);
    t4 = (t0 + 1992U);
    t8 = *((char **)t4);
    t9 = *((int *)t8);
    t10 = (t9 == 2);
    if (t10 != 0)
        goto LAB8;

LAB10:    xsi_set_current_line(90, ng0);
    t2 = (t0 + 2152U);
    t4 = *((char **)t2);
    t2 = (t0 + 6836);
    t9 = xsi_mem_cmp(t2, t4, 4U);
    if (t9 == 1)
        goto LAB35;

LAB46:    t8 = (t0 + 6840);
    t13 = xsi_mem_cmp(t8, t4, 4U);
    if (t13 == 1)
        goto LAB36;

LAB47:    t12 = (t0 + 6844);
    t16 = xsi_mem_cmp(t12, t4, 4U);
    if (t16 == 1)
        goto LAB37;

LAB48:    t15 = (t0 + 6848);
    t19 = xsi_mem_cmp(t15, t4, 4U);
    if (t19 == 1)
        goto LAB38;

LAB49:    t18 = (t0 + 6852);
    t22 = xsi_mem_cmp(t18, t4, 4U);
    if (t22 == 1)
        goto LAB39;

LAB50:    t21 = (t0 + 6856);
    t25 = xsi_mem_cmp(t21, t4, 4U);
    if (t25 == 1)
        goto LAB40;

LAB51:    t24 = (t0 + 6860);
    t28 = xsi_mem_cmp(t24, t4, 4U);
    if (t28 == 1)
        goto LAB41;

LAB52:    t27 = (t0 + 6864);
    t31 = xsi_mem_cmp(t27, t4, 4U);
    if (t31 == 1)
        goto LAB42;

LAB53:    t30 = (t0 + 6868);
    t34 = xsi_mem_cmp(t30, t4, 4U);
    if (t34 == 1)
        goto LAB43;

LAB54:    t33 = (t0 + 6872);
    t37 = xsi_mem_cmp(t33, t4, 4U);
    if (t37 == 1)
        goto LAB44;

LAB55:
LAB45:    xsi_set_current_line(112, ng0);
    t2 = (t0 + 6956);
    t5 = (t0 + 4432);
    t8 = (t5 + 56U);
    t11 = *((char **)t8);
    t12 = (t11 + 56U);
    t14 = *((char **)t12);
    memcpy(t14, t2, 8U);
    xsi_driver_first_trans_fast_port(t5);

LAB34:
LAB9:    goto LAB3;

LAB5:    t4 = (t0 + 1032U);
    t5 = *((char **)t4);
    t6 = *((unsigned char *)t5);
    t7 = (t6 == (unsigned char)3);
    t1 = t7;
    goto LAB7;

LAB8:    xsi_set_current_line(65, ng0);
    t4 = (t0 + 2152U);
    t11 = *((char **)t4);
    t4 = (t0 + 6708);
    t13 = xsi_mem_cmp(t4, t11, 4U);
    if (t13 == 1)
        goto LAB12;

LAB23:    t14 = (t0 + 6712);
    t16 = xsi_mem_cmp(t14, t11, 4U);
    if (t16 == 1)
        goto LAB13;

LAB24:    t17 = (t0 + 6716);
    t19 = xsi_mem_cmp(t17, t11, 4U);
    if (t19 == 1)
        goto LAB14;

LAB25:    t20 = (t0 + 6720);
    t22 = xsi_mem_cmp(t20, t11, 4U);
    if (t22 == 1)
        goto LAB15;

LAB26:    t23 = (t0 + 6724);
    t25 = xsi_mem_cmp(t23, t11, 4U);
    if (t25 == 1)
        goto LAB16;

LAB27:    t26 = (t0 + 6728);
    t28 = xsi_mem_cmp(t26, t11, 4U);
    if (t28 == 1)
        goto LAB17;

LAB28:    t29 = (t0 + 6732);
    t31 = xsi_mem_cmp(t29, t11, 4U);
    if (t31 == 1)
        goto LAB18;

LAB29:    t32 = (t0 + 6736);
    t34 = xsi_mem_cmp(t32, t11, 4U);
    if (t34 == 1)
        goto LAB19;

LAB30:    t35 = (t0 + 6740);
    t37 = xsi_mem_cmp(t35, t11, 4U);
    if (t37 == 1)
        goto LAB20;

LAB31:    t38 = (t0 + 6744);
    t40 = xsi_mem_cmp(t38, t11, 4U);
    if (t40 == 1)
        goto LAB21;

LAB32:
LAB22:    xsi_set_current_line(87, ng0);
    t2 = (t0 + 6828);
    t5 = (t0 + 4432);
    t8 = (t5 + 56U);
    t11 = *((char **)t8);
    t12 = (t11 + 56U);
    t14 = *((char **)t12);
    memcpy(t14, t2, 8U);
    xsi_driver_first_trans_fast_port(t5);

LAB11:    goto LAB9;

LAB12:    xsi_set_current_line(67, ng0);
    t41 = (t0 + 6748);
    t43 = (t0 + 4432);
    t44 = (t43 + 56U);
    t45 = *((char **)t44);
    t46 = (t45 + 56U);
    t47 = *((char **)t46);
    memcpy(t47, t41, 8U);
    xsi_driver_first_trans_fast_port(t43);
    goto LAB11;

LAB13:    xsi_set_current_line(69, ng0);
    t2 = (t0 + 6756);
    t5 = (t0 + 4432);
    t8 = (t5 + 56U);
    t11 = *((char **)t8);
    t12 = (t11 + 56U);
    t14 = *((char **)t12);
    memcpy(t14, t2, 8U);
    xsi_driver_first_trans_fast_port(t5);
    goto LAB11;

LAB14:    xsi_set_current_line(71, ng0);
    t2 = (t0 + 6764);
    t5 = (t0 + 4432);
    t8 = (t5 + 56U);
    t11 = *((char **)t8);
    t12 = (t11 + 56U);
    t14 = *((char **)t12);
    memcpy(t14, t2, 8U);
    xsi_driver_first_trans_fast_port(t5);
    goto LAB11;

LAB15:    xsi_set_current_line(73, ng0);
    t2 = (t0 + 6772);
    t5 = (t0 + 4432);
    t8 = (t5 + 56U);
    t11 = *((char **)t8);
    t12 = (t11 + 56U);
    t14 = *((char **)t12);
    memcpy(t14, t2, 8U);
    xsi_driver_first_trans_fast_port(t5);
    goto LAB11;

LAB16:    xsi_set_current_line(75, ng0);
    t2 = (t0 + 6780);
    t5 = (t0 + 4432);
    t8 = (t5 + 56U);
    t11 = *((char **)t8);
    t12 = (t11 + 56U);
    t14 = *((char **)t12);
    memcpy(t14, t2, 8U);
    xsi_driver_first_trans_fast_port(t5);
    goto LAB11;

LAB17:    xsi_set_current_line(77, ng0);
    t2 = (t0 + 6788);
    t5 = (t0 + 4432);
    t8 = (t5 + 56U);
    t11 = *((char **)t8);
    t12 = (t11 + 56U);
    t14 = *((char **)t12);
    memcpy(t14, t2, 8U);
    xsi_driver_first_trans_fast_port(t5);
    goto LAB11;

LAB18:    xsi_set_current_line(79, ng0);
    t2 = (t0 + 6796);
    t5 = (t0 + 4432);
    t8 = (t5 + 56U);
    t11 = *((char **)t8);
    t12 = (t11 + 56U);
    t14 = *((char **)t12);
    memcpy(t14, t2, 8U);
    xsi_driver_first_trans_fast_port(t5);
    goto LAB11;

LAB19:    xsi_set_current_line(81, ng0);
    t2 = (t0 + 6804);
    t5 = (t0 + 4432);
    t8 = (t5 + 56U);
    t11 = *((char **)t8);
    t12 = (t11 + 56U);
    t14 = *((char **)t12);
    memcpy(t14, t2, 8U);
    xsi_driver_first_trans_fast_port(t5);
    goto LAB11;

LAB20:    xsi_set_current_line(83, ng0);
    t2 = (t0 + 6812);
    t5 = (t0 + 4432);
    t8 = (t5 + 56U);
    t11 = *((char **)t8);
    t12 = (t11 + 56U);
    t14 = *((char **)t12);
    memcpy(t14, t2, 8U);
    xsi_driver_first_trans_fast_port(t5);
    goto LAB11;

LAB21:    xsi_set_current_line(85, ng0);
    t2 = (t0 + 6820);
    t5 = (t0 + 4432);
    t8 = (t5 + 56U);
    t11 = *((char **)t8);
    t12 = (t11 + 56U);
    t14 = *((char **)t12);
    memcpy(t14, t2, 8U);
    xsi_driver_first_trans_fast_port(t5);
    goto LAB11;

LAB33:;
LAB35:    xsi_set_current_line(92, ng0);
    t36 = (t0 + 6876);
    t39 = (t0 + 4432);
    t41 = (t39 + 56U);
    t42 = *((char **)t41);
    t43 = (t42 + 56U);
    t44 = *((char **)t43);
    memcpy(t44, t36, 8U);
    xsi_driver_first_trans_fast_port(t39);
    goto LAB34;

LAB36:    xsi_set_current_line(94, ng0);
    t2 = (t0 + 6884);
    t5 = (t0 + 4432);
    t8 = (t5 + 56U);
    t11 = *((char **)t8);
    t12 = (t11 + 56U);
    t14 = *((char **)t12);
    memcpy(t14, t2, 8U);
    xsi_driver_first_trans_fast_port(t5);
    goto LAB34;

LAB37:    xsi_set_current_line(96, ng0);
    t2 = (t0 + 6892);
    t5 = (t0 + 4432);
    t8 = (t5 + 56U);
    t11 = *((char **)t8);
    t12 = (t11 + 56U);
    t14 = *((char **)t12);
    memcpy(t14, t2, 8U);
    xsi_driver_first_trans_fast_port(t5);
    goto LAB34;

LAB38:    xsi_set_current_line(98, ng0);
    t2 = (t0 + 6900);
    t5 = (t0 + 4432);
    t8 = (t5 + 56U);
    t11 = *((char **)t8);
    t12 = (t11 + 56U);
    t14 = *((char **)t12);
    memcpy(t14, t2, 8U);
    xsi_driver_first_trans_fast_port(t5);
    goto LAB34;

LAB39:    xsi_set_current_line(100, ng0);
    t2 = (t0 + 6908);
    t5 = (t0 + 4432);
    t8 = (t5 + 56U);
    t11 = *((char **)t8);
    t12 = (t11 + 56U);
    t14 = *((char **)t12);
    memcpy(t14, t2, 8U);
    xsi_driver_first_trans_fast_port(t5);
    goto LAB34;

LAB40:    xsi_set_current_line(102, ng0);
    t2 = (t0 + 6916);
    t5 = (t0 + 4432);
    t8 = (t5 + 56U);
    t11 = *((char **)t8);
    t12 = (t11 + 56U);
    t14 = *((char **)t12);
    memcpy(t14, t2, 8U);
    xsi_driver_first_trans_fast_port(t5);
    goto LAB34;

LAB41:    xsi_set_current_line(104, ng0);
    t2 = (t0 + 6924);
    t5 = (t0 + 4432);
    t8 = (t5 + 56U);
    t11 = *((char **)t8);
    t12 = (t11 + 56U);
    t14 = *((char **)t12);
    memcpy(t14, t2, 8U);
    xsi_driver_first_trans_fast_port(t5);
    goto LAB34;

LAB42:    xsi_set_current_line(106, ng0);
    t2 = (t0 + 6932);
    t5 = (t0 + 4432);
    t8 = (t5 + 56U);
    t11 = *((char **)t8);
    t12 = (t11 + 56U);
    t14 = *((char **)t12);
    memcpy(t14, t2, 8U);
    xsi_driver_first_trans_fast_port(t5);
    goto LAB34;

LAB43:    xsi_set_current_line(108, ng0);
    t2 = (t0 + 6940);
    t5 = (t0 + 4432);
    t8 = (t5 + 56U);
    t11 = *((char **)t8);
    t12 = (t11 + 56U);
    t14 = *((char **)t12);
    memcpy(t14, t2, 8U);
    xsi_driver_first_trans_fast_port(t5);
    goto LAB34;

LAB44:    xsi_set_current_line(110, ng0);
    t2 = (t0 + 6948);
    t5 = (t0 + 4432);
    t8 = (t5 + 56U);
    t11 = *((char **)t8);
    t12 = (t11 + 56U);
    t14 = *((char **)t12);
    memcpy(t14, t2, 8U);
    xsi_driver_first_trans_fast_port(t5);
    goto LAB34;

LAB56:;
}


extern void work_a_1503986837_3212880686_init()
{
	static char *pe[] = {(void *)work_a_1503986837_3212880686_p_0,(void *)work_a_1503986837_3212880686_p_1,(void *)work_a_1503986837_3212880686_p_2};
	xsi_register_didat("work_a_1503986837_3212880686", "isim/top_sim_isim_beh.exe.sim/work/a_1503986837_3212880686.didat");
	xsi_register_executes(pe);
}
